var count = 0;


for (var i = 0; i < 7; i++){
		count = i + 2 ;
		var pound = Array(count).join('#');
		console.log(pound);
}
